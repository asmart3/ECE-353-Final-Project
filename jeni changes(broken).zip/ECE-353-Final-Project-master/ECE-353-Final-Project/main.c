
#include "main.h"

//*****************************************************************************
// Global Vars
//*****************************************************************************
barrier barriers[5];
int numBarriers = 5;
int SPEED = 3; //lower number is faster
//direction of the player's tank
volatile PS2_DIR_t TANK_DIRECTION = PS2_DIR_CENTER;
//volatile bool alert_move = false;
tank player;
bool alert_move = false;
//****************************************************
//*****************************************************************************
void DisableInterrupts(void)
{
  __asm {
         CPSID  I
  }
}

//*****************************************************************************
//*****************************************************************************
void EnableInterrupts(void)
{
  __asm {
    CPSIE  I
  }
}
//function to blink lights
void timer1_handler(){
	static uint32_t i = 0;
	if (trigger_timer1){
		lp_io_set_pin(RED_BIT | BLUE_BIT | GREEN_BIT);
		//for the delay
		for (i = 0; i < 100000 ; i++) {}
			//leds off
			lp_io_clear_pin(RED_BIT | BLUE_BIT | GREEN_BIT);
			//to clear alert
			trigger_timer1 = false;
	}
}
//Check Tank Collision with Barrier
bool checkCollision(int xPos, int yPos){
	int i;
	int rightSide,bottomSide;
	
	xPos /=SPEED;
	yPos /=SPEED;
	xPos -=16;
	yPos -=16;
	rightSide = xPos + upTankWidth;//+16;
	bottomSide = yPos + upTankHeight;//+16;
	
	for(i = 0; i<5;i++){
		//checks to see if any of the barriers are broken
		if(!barriers[i].broken){
			//check x position
			if(((rightSide>=barriers[i].xPos)&&(rightSide<=(barriers[i].xPos+barriers[i].width))) || ((xPos <= (barriers[i].xPos + barriers[i].width)) && (xPos>=barriers[i].xPos))){
				//check y position
				if(((yPos>=barriers[i].yPos)&&(yPos<=(barriers[i].yPos+barriers[i].height))) || ((bottomSide <= (barriers[i].yPos + barriers[i].height)) && (bottomSide>=barriers[i].yPos))){
					return true;
				}
			}
		}
	}
	
	return false;
}





// PlayerMovement
void playerMove(tank *player, bool *alert_move, volatile PS2_DIR_t TANK_DIRECTION){
	if (TANK_DIRECTION == PS2_DIR_LEFT){
		//checks for contact of edge
			if((player->xPos/SPEED - (upTankWidth/2))>0){
				//checks for barrier contact
				if(!checkCollision(player->xPos -1,player->yPos)){
					//moves player in the left direction
					player->direction = left;
					player->xPos -= 1;
					//alerts the program to redraw the tank
					*alert_move = true;
				}
				
			}
		}else if(TANK_DIRECTION == PS2_DIR_RIGHT){
			//checks for contact of edge
			if((player->xPos/SPEED + (upTankWidth/2))<COLS){
				//checks for barrier contact
				if(!checkCollision(player->xPos+1,player->yPos)){
					//moves player in the right direction
					player->direction = right;
					player->xPos += 1;
					*alert_move = true;
				}
			}
		}
		
		if (TANK_DIRECTION == PS2_DIR_UP){
			//checks for contact of edge
			if((player->yPos/SPEED - (upTankWidth/2))>0){
				//checks for barrier contact
				if(!checkCollision(player->xPos,player->yPos-1)){
					//moves player in the up direction
					player->direction = up;
					player->yPos -= 1;
					//alerts the program to redraw the tank
					*alert_move = true;
				}
			}
		}else if(TANK_DIRECTION == PS2_DIR_DOWN){
			//checks for contact of edge
			if((player->yPos/SPEED + (upTankWidth/2))<ROWS){
				//checks for barrier contact
				if(!checkCollision(player->xPos,player->yPos+1)){
					//moves player in the down direction
					player->direction = down;
					player->yPos += 1;
					*alert_move = true;
				}
			}
		}
	
}


void initBarriers(){
	int i;
	barrier block ={40,40,40,40,false};
	barrier block2 ={20,20,20,20,true};
	barrier block3 ={180,220,35,35,false};
	
	barriers[0] = block; 
	barriers[1] = block3;
	for(i = 2;i<numBarriers;i++){
		barriers[i] = block2;
	}
	
	
}

void drawBarriers(){
	int i;
	for(i=0;i<numBarriers;i++){
		if(!barriers[i].broken)
			lcd_draw_box(barriers[i].xPos,barriers[i].width,barriers[i].yPos,barriers[i].height,LCD_COLOR_RED,LCD_COLOR_BLACK,2);
	}
	
		
}



int main(void)
{
	
	bool game_over = false;
	//initializes the player
	player.xPos = 100 * SPEED;
	player.yPos = 100 * SPEED;
	player.direction = up;
	
		//initialize_serial_debug();
			
		//put_string("\n\r******************************\n\r");
		//put_string("ECE353 Final Project Spring 2020\n\r");
		//put_string("Jennifer Kaiser, Andrew Smart, Matthew Beyer");
	//	put_string("\n\r");
	//	put_string("******************************\n\r");  
		
		init_hardware();
		config_timer1();
		lp_io_init();
		lcd_draw_image(player.xPos/SPEED,upTankWidth,player.yPos/SPEED,upTankHeight,upTank,LCD_COLOR_GREEN,LCD_COLOR_BLACK);
		initBarriers();
		
	while(!game_over){
		//handles
		timer1_handler();
		if(alert_move){
			switch(player.direction){
				case up:
					lcd_draw_image(player.xPos/SPEED,upTankWidth,player.yPos/SPEED,upTankHeight,upTank,LCD_COLOR_GREEN,LCD_COLOR_BLACK);
					break;
				case down:
					lcd_draw_image(player.xPos/SPEED,downTankWidth,player.yPos/SPEED,downTankHeight,downTank,LCD_COLOR_GREEN,LCD_COLOR_BLACK);
					break;
				case left:
					lcd_draw_image(player.xPos/SPEED,leftTankWidth,player.yPos/SPEED,leftTankHeight,leftTank,LCD_COLOR_GREEN,LCD_COLOR_BLACK);
					break;
				case right:
					lcd_draw_image(player.xPos/SPEED,rightTankWidth,player.yPos/SPEED,rightTankHeight,rightTank,LCD_COLOR_GREEN,LCD_COLOR_BLACK);
					break;
			}
				
		}
		//Checks for interupt 
		if(TIMER2_ALERT){
			//check x,y ps2 positions
			
			//PS2_DIR = PS2_DIR_DOWN;
			playerMove(&player, &alert_move, PS2_DIR);
			TIMER2_ALERT = false;
		}
		
		
		//barriers
		drawBarriers();
		
	}
	
}  




//*****************************************************************************
// Initializes all of the peripherls used in HW3
//*****************************************************************************
void init_hardware(void)
{
  lcd_config_gpio();
  lcd_config_screen();
  lcd_clear_screen(LCD_COLOR_BLACK);
  ps2_initialize();
  init_serial_debug(false,false);
  // Update the Space Shipt 60 times per second.
  gp_timer_config_32(TIMER2_BASE,TIMER_TAMR_TAMR_PERIOD, 1000000, false, true);
  gp_timer_config_32(TIMER3_BASE,TIMER_TAMR_TAMR_PERIOD, 500000, false, true);
  gp_timer_config_32(TIMER4_BASE,TIMER_TAMR_TAMR_PERIOD, 50000, false, true);
}


