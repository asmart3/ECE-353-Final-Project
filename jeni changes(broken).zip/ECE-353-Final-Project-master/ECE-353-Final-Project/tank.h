
typedef struct
{
	int xPos;
	int yPos;
	int direction;
	int delay; // time since last shot
}	tank;