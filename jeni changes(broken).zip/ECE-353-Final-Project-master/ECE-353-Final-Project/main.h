#ifndef __MAIN_H__
#define __MAIN_H__
#define   RED_BIT       1
#define   BLUE_BIT      2
#define   GREEN_BIT     3
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#include "TM4C123.h"
#include "gpio_port.h"
#include "ps2.h"
#include "lcd.h"
#include "launchpad_io.h"
#include "serial_debug.h"
#include "timers.h"
//#include "tank.h"
#include "images.h"
#include "interrupts.h"


extern void init_hardware(void);

enum direction{up,down,left,right};

typedef struct
{
	int xPos;
	int yPos;
	enum direction direction;
	int delay; // time since last shot
}	tank;

typedef struct
{
	int xPos;
	int yPos;
	int width;
	int height;
	bool broken;
} barrier;

typedef enum{
  PS2_DIR_UP,
  PS2_DIR_DOWN,
  PS2_DIR_LEFT,
  PS2_DIR_RIGHT,
  PS2_DIR_CENTER,
  PS2_DIR_INIT,
} PS2_DIR_t;


extern volatile PS2_DIR_t PS2_DIR;
extern volatile bool TIMER2_ALERT;


#endif
